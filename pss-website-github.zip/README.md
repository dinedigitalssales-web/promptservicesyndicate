# Prompt Services Syndicate — Official Website

A fully static, production-ready 5-page corporate website for **Prompt Services Syndicate**, Pakistan's premier customs clearance and logistics enterprise.

## 🌐 Live Site

> Deploy via GitHub Pages: `https://<your-username>.github.io/pss-website/`

---

## 📁 Project Structure

```
pss-website/
├── index.html        # Home page
├── about.html        # About Us
├── services.html     # Services
├── news.html         # News & Insights
├── contact.html      # Contact Us
├── style.css         # Global stylesheet
├── script.js         # Global JavaScript
├── logo.png          # Brand logo asset
└── README.md         # This file
```

---

## 🚀 Deploying to GitHub Pages

### Step 1 — Create a new GitHub repository

1. Go to [github.com](https://github.com) and sign in
2. Click **New repository**
3. Name it `pss-website` (or any name you prefer)
4. Set visibility to **Public**
5. Do **NOT** initialise with a README (you already have one)
6. Click **Create repository**

---

### Step 2 — Push this code to GitHub

Open your terminal, navigate to this project folder, then run:

```bash
# Initialise git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit — PSS website"

# Add your GitHub repo as the remote origin
# Replace YOUR_USERNAME and YOUR_REPO_NAME below
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git

# Push to main branch
git branch -M main
git push -u origin main
```

---

### Step 3 — Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** → **Pages** (left sidebar)
3. Under **Source**, select **Deploy from a branch**
4. Choose branch: `main` / folder: `/ (root)`
5. Click **Save**
6. Wait ~60 seconds, then visit:
   `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`

---

## ✨ Features

| Feature | Detail |
|---|---|
| Pages | 5 (Home, About, Services, News, Contact) |
| Design | Dark Blue `#0E2761` + Gold `#C9A84C` corporate palette |
| Typography | Inter + Montserrat (Google Fonts) |
| Animations | Particle network hero canvas, scroll-reveal, counter animations |
| Interactive | Volume Estimator widget, Article modals, FAQ accordion |
| Responsive | Mobile, tablet, desktop, ultrawide |
| Dependencies | Zero — pure HTML/CSS/JS, no frameworks or npm |

---

## 🛠 Local Development

No build step required. Simply open `index.html` in your browser:

```bash
# Option A — just open directly
open index.html

# Option B — serve locally with Python
python3 -m http.server 8000
# then visit http://localhost:8000

# Option C — serve with Node
npx serve .
```

---

## 📝 Customisation Checklist

Before going live, update the following:

- [ ] `logo.png` — replace with final brand asset if needed
- [ ] Contact details — phone numbers and email addresses in `contact.html` and footer of all pages
- [ ] Office addresses — Karachi and Lahore addresses in `contact.html`
- [ ] Google Maps link — update the "Open in Google Maps" anchor in `contact.html`
- [ ] Social media links — LinkedIn and Twitter URLs in footer of `index.html`
- [ ] Domain — if using a custom domain, add a `CNAME` file to the repo root with your domain name

---

## 📄 License

© 2025 Prompt Services Syndicate. All Rights Reserved.
