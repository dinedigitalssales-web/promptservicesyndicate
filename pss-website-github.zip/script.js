/* ============================================
   PROMPT SERVICES SYNDICATE — GLOBAL SCRIPTS
   ============================================ */

// ---- Mobile Menu ----
const hamburger = document.querySelector('.nav-hamburger');
const mobileMenu = document.querySelector('.mobile-menu');
const mobileClose = document.querySelector('.mobile-close');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => mobileMenu.classList.add('open'));
  if (mobileClose) mobileClose.addEventListener('click', () => mobileMenu.classList.remove('open'));
}

// ---- Reveal on Scroll ----
const revealEls = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      setTimeout(() => e.target.classList.add('visible'), (e.target.dataset.delay || 0) * 1);
      revealObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.12 });
revealEls.forEach(el => revealObserver.observe(el));

// ---- Animated Counters ----
function animateCounter(el) {
  const target = parseInt(el.dataset.target, 10);
  const duration = 1800;
  const start = performance.now();
  function update(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target).toLocaleString() + (el.dataset.suffix || '');
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}
const counterEls = document.querySelectorAll('[data-target]');
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      animateCounter(e.target);
      counterObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.4 });
counterEls.forEach(el => counterObserver.observe(el));

// ---- Sticky Nav Scroll Effect ----
const navbar = document.querySelector('.navbar');
window.addEventListener('scroll', () => {
  if (navbar) {
    if (window.scrollY > 40) {
      navbar.style.background = 'rgba(14,39,97,0.98)';
      navbar.style.boxShadow = '0 4px 24px rgba(14,39,97,0.25)';
    } else {
      navbar.style.background = 'rgba(14,39,97,0.92)';
      navbar.style.boxShadow = 'none';
    }
  }
});

// ---- Estimator Widget ----
const estimatorForm = document.getElementById('estimator-form');
if (estimatorForm) {
  const volumeInput = document.getElementById('est-volume');
  const pathwaySelect = document.getElementById('est-pathway');
  const serviceSelect = document.getElementById('est-service');
  const resultDiv = document.getElementById('estimator-result');
  const inquiryDiv = document.getElementById('estimator-inquiry');

  document.getElementById('est-calculate').addEventListener('click', () => {
    const volume = parseFloat(volumeInput.value) || 0;
    const pathway = pathwaySelect.value;
    const service = serviceSelect.value;
    if (!volume || !pathway || !service) {
      alert('Please fill in all estimator fields.');
      return;
    }

    const pathwayFactor = { sea: 1.0, air: 1.6, land: 1.25 };
    const serviceFactor = { standard: 1.0, endtoend: 1.5, specialized: 2.2 };
    const complexity = Math.min(Math.round((volume / 100) * pathwayFactor[pathway] * serviceFactor[service] * 10), 100);
    let tier = complexity < 35 ? 'Low Complexity' : complexity < 65 ? 'Moderate Complexity' : 'High Complexity';
    let tierColor = complexity < 35 ? '#22a752' : complexity < 65 ? '#e08a14' : '#c0392b';

    resultDiv.innerHTML = `
      <div style="padding:28px;border:2px solid ${tierColor};border-radius:8px;background:rgba(${complexity<35?'34,167,82':complexity<65?'224,138,20':'192,57,43'},0.06)">
        <div style="font-size:0.75rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:${tierColor};margin-bottom:6px">Operational Complexity Assessment</div>
        <div style="font-size:2.6rem;font-weight:900;color:${tierColor};font-family:'Montserrat',sans-serif;line-height:1">${complexity}<span style="font-size:1.2rem">/100</span></div>
        <div style="font-size:1rem;font-weight:700;color:var(--charcoal);margin:8px 0">${tier}</div>
        <p style="font-size:0.88rem;color:var(--muted);max-width:none">
          Based on ${volume.toLocaleString()} CBM/MT via <strong>${pathway.charAt(0).toUpperCase()+pathway.slice(1)} Freight</strong> 
          with <strong>${service === 'endtoend' ? 'End-to-End Freight' : service === 'specialized' ? 'Specialized Project Logistics' : 'Standard Clearance'}</strong>. 
          Our team will review your specific commodity codes and regulatory obligations.
        </p>
        <div style="margin-top:16px;height:8px;background:#e8eaf0;border-radius:4px;overflow:hidden">
          <div style="width:${complexity}%;height:100%;background:${tierColor};border-radius:4px;transition:width 1s ease"></div>
        </div>
      </div>`;
    resultDiv.style.display = 'block';
    inquiryDiv.style.display = 'block';
    resultDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });
}

// ---- Newsletter Form ----
const newsletterForms = document.querySelectorAll('.newsletter-form-js');
newsletterForms.forEach(form => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = form.querySelector('input');
    const btn = form.querySelector('button');
    if (input && input.value) {
      btn.textContent = 'Subscribed ✓';
      btn.style.background = '#22a752';
      input.value = '';
      setTimeout(() => { btn.textContent = 'Subscribe'; btn.style.background = ''; }, 3000);
    }
  });
});

// ---- Contact Form ----
const contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('button[type="submit"]');
    btn.textContent = 'Message Received ✓';
    btn.style.background = '#22a752';
    btn.style.borderColor = '#22a752';
    setTimeout(() => {
      btn.textContent = 'Submit Corporate Inquiry';
      btn.style.background = '';
      btn.style.borderColor = '';
      contactForm.reset();
    }, 4000);
  });
}
